# 📊 Trader Performance vs Market Sentiment
### Primetrade.ai — Data Science Intern Assignment

---

## 🚀 Setup & Run

```bash
# 1. Clone / unzip the repo
# 2. Place datasets in the root folder:
#    - fear_greed_index.csv
#    - historical_data.csv

# 3. Install dependencies
pip install pandas numpy matplotlib seaborn scikit-learn jupyter

# 4. Create outputs folder
mkdir outputs

# 5. Run the notebook
jupyter notebook trader_sentiment_analysis.ipynb
```

---

## 📁 Repository Structure

```
├── trader_sentiment_analysis.ipynb   # Main analysis notebook
├── README.md                         # This file
├── fear_greed_index.csv              # Bitcoin Fear/Greed Index (2018–2025)
├── historical_data.csv               # Hyperliquid trader data (2023–2025)
└── outputs/
    ├── chart1_pnl_distribution.png
    ├── chart2_behavior_metrics.png
    ├── chart3_drawdown.png
    ├── chart4_segmentation.png
    ├── chart5_sentiment_volume.png
    ├── chart6_long_short.png
    ├── chart7_feature_importance.png
    ├── sentiment_metrics_summary.csv
    └── account_segments.csv
```

---

## 📋 Methodology

### Data Overview
| Dataset | Rows | Columns | Date Range |
|---------|------|---------|------------|
| Fear/Greed Index | 2,644 | 4 | 2018-02-01 → 2025-05-02 |
| Hyperliquid Trades | 211,224 | 16 | 2023-05-01 → 2025-05-01 |
| After merge | 211,218 | — | 2023-05-01 → 2025-05-01 |

### Part A — Data Preparation
- **Timestamps**: Parsed `Timestamp IST` (format `%d-%m-%Y %H:%M`) → `date`
- **Sentiment bucketing**: Mapped `Extreme Fear/Greed` → `Fear/Greed` for cleaner 3-bucket analysis
- **Leverage proxy**: `Size USD / Execution Price` (clipped 0–200x) — no raw leverage column in data
- **Direction flags**: Binary `is_long`, `is_short`, `is_win` from `Direction` field
- **Daily aggregation**: Per account-day: PnL sum, trade count, win rate, avg size, avg leverage, L/S ratio
- **Drawdown**: Cumulative PnL → rolling max → drawdown = cum_pnl − roll_max

### Part B — Analysis Questions

**1. Does performance differ between Fear vs Greed days?**
Yes. Fear days show **higher average daily PnL ($5,185) and larger trade sizes**, 
while Greed days have a **higher median PnL** ($265 vs $122) — suggesting Fear days 
have more variance with bigger wins but also bigger losses.

**2. Do traders change behavior based on sentiment?**
Yes. On Fear days, traders execute **more trades per day** and deploy **larger average
position sizes**. The long/short ratio shifts: traders are more long-heavy on Greed days
and more balanced on Fear days.

**3. Trader Segments Identified:**
- **High vs Low Leverage**: Low-leverage traders earn more on average; high-leverage traders
  have higher variance and worse drawdowns.
- **Frequent vs Infrequent**: Infrequent traders have *higher average win rates*, suggesting
  more selective, better-quality entries.
- **Consistent Winners vs Inconsistent**: Consistent winners maintain profitability across all
  sentiment states; Inconsistent traders bleed worst on Fear days.

---

## 💡 Key Insights

| # | Insight | Chart |
|---|---------|-------|
| 1 | **Fear days yield highest average PnL** ($5,185 avg vs $4,144 on Greed) — fearful markets create mispricings | Chart 1, 2 |
| 2 | **Traders are most active on Fear days** — larger trade sizes and higher frequency | Chart 2 |
| 3 | **Low-leverage traders consistently outperform** high-leverage traders in total PnL | Chart 4 |
| 4 | **Long bias peaks on Greed days** (crowd goes long) — mean reversion opportunity for contrarians | Chart 6 |
| 5 | **Win rate + trade frequency are top predictors** of profitability bucket (RF model) | Chart 7 |

---

## 🎯 Strategy Recommendations (Part C)

### Strategy 1 — Fear Accumulation Rule
> **"During Fear days (F&G < 35), low-leverage traders should increase position sizes by 20–30%"**

- **Evidence**: Fear days generate the highest avg PnL. Low-leverage traders have the best
  risk-adjusted returns. Fear = mispriced assets + less competition.
- **Implementation**: When F&G Index < 35 AND rolling 7-day win rate > 55% → size up 25%.
  Hard stop: −2% portfolio drawdown per day.
- **Who it applies to**: Infrequent, low-leverage traders (Segment: Consistent Winners)

### Strategy 2 — Greed Day Short Hedge
> **"During Greed days (F&G > 70), consistent winner accounts should tilt 10–15% short"**

- **Evidence**: Long/short ratio spikes on Greed days — the crowd over-extends long.
  Consistent winners who add a short hedge capture mean-reversion alpha when euphoria fades.
- **Implementation**: When F&G Index > 70 → reduce long exposure by 15%, add 5–10% short hedge.
  Exit shorts when index drops below 60.
- **Who it applies to**: Consistent winners with avg win rate > 55%

---

## 🤖 Bonus: Predictive Model

A Random Forest classifier was trained to predict **next-day PnL bucket**
(`Big Loss / Small Loss / Small Win / Big Win`) using:
- Sentiment encoding
- Avg leverage proxy
- Avg trade size
- Trade count
- Win rate
- Long/short ratio

**Overall Accuracy: ~87%** (dominated by Small Loss class — reflects real data distribution).
Top features: `win_rate`, `trade_count`, `avg_size_usd`

---

*Submitted by: [Your Name] | [Your Email] | March 2025*
